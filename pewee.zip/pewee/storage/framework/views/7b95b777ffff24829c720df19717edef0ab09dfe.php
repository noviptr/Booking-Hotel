<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(url('/')); ?>">
                <div class="sidebar-brand-text mx-3"><?php echo e(__('Homepage')); ?></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item <?php echo e(request()->is('admin/dashboard') || request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard.index')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span><?php echo e(__('Dashboard')); ?></span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <span><?php echo e(__('User Management')); ?></span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.permissions.index')); ?>"> <i class="fa fa-briefcase mr-2"></i> <?php echo e(__('Permissions')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.roles.index')); ?>"><i class="fa fa-briefcase mr-2"></i> <?php echo e(__('Roles')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>"> <i class="fa fa-user mr-2"></i> <?php echo e(__('Users')); ?></a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseRoom" aria-expanded="true" aria-controls="collapseTwo">
                    <span><?php echo e(__('Room Management')); ?></span>
                </a>
                <div id="collapseRoom" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(request()->is('admin/countries') || request()->is('admin/countries/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.countries.index')); ?>"> <i class="fa fa-briefcase mr-2"></i> <?php echo e(__('country')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/categories') || request()->is('admin/categories/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.index')); ?>"> <i class="fa fa-user mr-2"></i> <?php echo e(__('category')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/rooms') || request()->is('admin/rooms/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.rooms.index')); ?>"><i class="fa fa-briefcase mr-2"></i> <?php echo e(__('room')); ?></a>
                    </div>
                </div>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseBooking" aria-expanded="true" aria-controls="collapseTwo">
                    <span><?php echo e(__('Booking Management')); ?></span>
                </a>
                <div id="collapseBooking" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(request()->is('admin/customers') || request()->is('admin/customers/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.customers.index')); ?>"> <i class="fa fa-briefcase mr-2"></i> <?php echo e(__('customer')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/bookings') || request()->is('admin/bookings/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.bookings.index')); ?>"><i class="fa fa-briefcase mr-2"></i> <?php echo e(__('booking')); ?></a>
                        <a class="collapse-item <?php echo e(request()->is('admin/find_rooms') || request()->is('admin/find_rooms/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.find_rooms.index')); ?>"> <i class="fa fa-user mr-2"></i> <?php echo e(__('find room')); ?></a>
                    </div>
                </div>
            </li>

                     <!-- Nav Item  -->
             <li class="nav-item <?php echo e(request()->is('admin/system_calendars') || request()->is('admin/system_calendars') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.system_calendars.index')); ?>">
                    <i class="fas fa-fw fa-calendar"></i>
                    <span><?php echo e(__('Calendar')); ?></span></a>
            </li>


        </ul><?php /**PATH D:\pewee\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>