<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<!-- Content Row -->
        <div class="card shadow">
            <div class="card-header py-3 d-flex">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('create room')); ?></h1>
                <div class="ml-auto">
                    <a href="<?php echo e(route('admin.rooms.index')); ?>" class="btn btn-primary">
                        <span class="text"><?php echo e(__('Go Back')); ?></span>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.rooms.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="room_number"><?php echo e(__('Room Number')); ?></label>
                        <input type="text" class="form-control" id="room_number" placeholder="<?php echo e(__('room number')); ?>" name="room_number" value="<?php echo e(old('room_number')); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="price"><?php echo e(__('Price')); ?></label>
                        <input type="number" class="form-control" id="price" placeholder="<?php echo e(__('price')); ?>" name="price" value="<?php echo e(old('price')); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="capacity"><?php echo e(__('Capacity')); ?></label>
                        <input type="number" class="form-control" id="capacity" placeholder="<?php echo e(__('capacity')); ?>" name="capacity" value="<?php echo e(old('capacity')); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="category"><?php echo e(__('Category')); ?></label>
                        <select class="form-control" name="category_id" id="category">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>"><?php echo e($category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="floor"><?php echo e(__('Floor')); ?></label>
                        <input type="number" class="form-control" id="floor" placeholder="<?php echo e(__('floor')); ?>" name="floor" value="<?php echo e(old('floor')); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="description"><?php echo e(__('Description')); ?></label>
                        <textarea class="form-control" name="description" id="descriptioin" placeholder="description" cols="30" rows="10"><?php echo e(old('description')); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('Save')); ?></button>
                </form>
            </div>
        </div>
    

    <!-- Content Row -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pewee\resources\views/admin/rooms/create.blade.php ENDPATH**/ ?>